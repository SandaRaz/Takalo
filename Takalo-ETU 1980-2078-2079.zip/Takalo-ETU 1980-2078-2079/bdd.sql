CREATE DATABASE takalo;
USE takalo;


CREATE TABLE admin(
    idAdmin int PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nomAdmin VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255)
);

CREATE TABLE utilisateur(
    idUtilisateur int PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nomUtilisateur VARCHAR(255),
    prenomUtilisateur VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255)
);

CREATE TABLE categorie(
    idCategorie int PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nomCategorie VARCHAR(255)
);

CREATE TABLE objet(
    idObjet int PRIMARY KEY NOT NULL AUTO_INCREMENT,
    titre VARCHAR(255),
    description TEXT,
    prix double precision,
    idCategorie int,  
    idUtilisateur int,
    etat int default 5
);


CREATE TABLE sary(
    idSary int PRIMARY KEY NOT NULL AUTO_INCREMENT,
    idObjet int, 
    nomSary VARCHAR(255)
);

CREATE TABLE echange(
    idEchange int PRIMARY KEY NOT NULL AUTO_INCREMENT,
    idDemandeur int,
    idReceveur int,
    idObjetDemandeur int,
    idObjetReceveur int,
    etat int default 1,
    daty timestamp
);





ALTER TABLE objet ADD FOREIGN KEY(idCategorie) REFERENCES categorie(idCategorie);
ALTER TABLE objet ADD FOREIGN KEY(idUtilisateur) REFERENCES utilisateur(idUtilisateur);
ALTER TABLE sary ADD FOREIGN KEY(idObjet) REFERENCES objet(idObjet);
ALTER TABLE echange ADD FOREIGN KEY(idDemandeur) REFERENCES utilisateur(idUtilisateur);
ALTER TABLE echange ADD FOREIGN KEY(idReceveur) REFERENCES utilisateur(idUtilisateur);
ALTER TABLE echange ADD FOREIGN KEY(idObjetDemandeur) REFERENCES objet(idObjet);
ALTER TABLE echange ADD FOREIGN KEY(idObjetReceveur) REFERENCES objet(idObjet);


INSERT INTO admin VALUES(null,'ITU','itu@gmail.com','itu');
INSERT INTO utilisateur VALUES(null,'Prof','Itu','prof@gmail.com','prof');


INSERT INTO categorie VALUES(null,'Technologie');


INSERT INTO objet values(null,'Smartphone Samsung Galaxy S21 5G','Un smartphone haut de gamme doté d un écran AMOLED de 6,2 pouces, d un appareil photo de 64 MP et d un processeur Snapdragon 888',300,1,1,5);
INSERT INTO objet values(null,'Laptop MacBook Air M2',' Un ordinateur portable léger et puissant doté d un écran Retina de 13,3 pouces, d un processeur M1 et de 8 Go de RAM.',300,1,1,5);
INSERT INTO objet values(null,'Ecouteurs sans fil AirPods Pro','Des écouteurs intra-auriculaires dotés de la réduction active du bruit et d une connexion sans fil rapide à votre appareil',300,1,1,5);
INSERT INTO objet values(null,' Smartwatch Apple Watch Series 6','UUne smartwatch conçue pour la santé et le fitness, avec des fonctionnalités telles que la mesure de l oxygène sanguin et des entraînements en direct',300,1,1,5);
INSERT INTO objet values(null,' Assistant vocal Amazon Echo Dot (4e génération)','Un assistant vocal intelligent qui peut contrôler vos appareils domestiques, jouer de la musique et répondre à vos questions',300,1,1,5);


INSERT INTO sary VALUES(null,1,'S21.jpg');
INSERT INTO sary VALUES(null,2,'macM2.jpeg');
INSERT INTO sary VALUES(null,3,'airPodsPro.png');
INSERT INTO sary VALUES(null,4,'smartWatch6.jpg');
INSERT INTO sary VALUES(null,5,'echoDot4.jpeg');
INSERT INTO sary VALUES(null,6,'echoDot4.jpg');

INSERT INTO objet values(null,' Assistant vocal Amazon Echo Dot (4e génération)','Un assistant vocal intelligent qui peut contrôler vos appareils domestiques, jouer de la musique et répondre à vos questions',100,1,2,5);




