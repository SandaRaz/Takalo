<?php 
	class DemandeEchange_model extends CI_Model{
		function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function listeDemandeEchange($idUtil){
			$query = $this->db->get_where('echange' , array('idReceveur' => $idUtil , 'etat' => 1));
			return $query->result();
		}

		public function getEchangebyId($idEchange){
			$query = $this->db->get_where('echange' , array('idEchange' => $idEchange));
			return $query->row();
		}

		public function changerEtatEchange($idEchange , $etat){
			$sql = "UPDATE echange SET etat = '%d' WHERE idEchange = '%d'";
			$sql = sprintf($sql , $etat , $idEchange);
			echo $sql;
			$this->db->query($sql);
		}

		public function changementProprietaire($idObjet , $idNewProp){
			$sql = "UPDATE objet SET idUtilisateur = '%d' WHERE idObjet = '%d'";
			$sql = sprintf($sql , $idNewProp , $idObjet);
			echo $sql;
			$this->db->query($sql);

			
		}

		public function insererEchange($data)
		{
			$this->db->insert('echange', $data);
			return $this->db->insert_id();
			
		}

		public function accepterEchange($idEchange){
			$echange = $this->getEchangebyId($idEchange);

			
			$this->changementProprietaire($echange->idObjetDemandeur , $echange->idReceveur);
			$this->changementProprietaire($echange->idObjetReceveur , $echange->idDemandeur);
			
			$this->changerEtatEchange($idEchange , 10);

			
		}

		public function refuserEchange($idEchange){
			$ligneaffectee = $this->changerEtatEchange($idEchange , -1);
			return $ligneaffectee;
		}

		public function getAllEchange()
		{
			$query = $this->db->get('echange');
			return $query->result;
		}
	}
?>