<?php 
	class ModifObjet_model extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
        
		public function update_objet($id, $data) {
			$this->db->update('objet', $data, array('idObjet' => $id));
			
		}
		public function getAllCategorie()
		{
			$query = $this->db->get('categorie');
			return $query->result();
		}
	
		public function getObjById($id)
		{
			$query = $this->db->query("SELECT * FROM objet WHERE idObjet=".$id);
			return $query->row();
		}

		public function liste_de_mes_objets($idUtil){
			$query = $this->db->query("SELECT * FROM objet o join categorie c on o.idCategorie=c.idCategorie where o.etat=5 and o.idUtilisateur=".$idUtil);

			return $query->result();
		}
        
	}
?>