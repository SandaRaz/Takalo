<?php 
	class AutreUserObjet_model extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function listesCategories(){
			$query = $this->db->get('categorie');
			
			return $query->result();
		}

		public function listesAutreUserObjet($idCategorie){
			$query = $this->db->get_where('objet' , array('idCategorie' => $idCategorie));
			$list = array();
			foreach ($query->result() as $key) {
				array_push($list, $key);
			}

			return $list;
		}

		public function listesAutresObjet($idUser,$idCategorie){
			$query = $this->db->query("SELECT * FROM objet o JOIN categorie c ON o.idCategorie=c.idCategorie where o.etat=5 and idUtilisateur!=".$idUser." and idCategorie=".$idCategorie);
			return $query->result();
		}

		public function AutresUserObjet($idUser){
			$query = $this->db->query("SELECT * FROM objet o JOIN categorie c ON o.idCategorie=c.idCategorie where o.etat=5 and idUtilisateur!=".$idUser);
			return $query->result();
		}

		public function getSaryByIdObject($id)
		{	
			$nomsary = array();

			$query = $this->db->get_where('sary',array('idObjet'=>$id));
			foreach($query->result() as $s){
				array_push($nomsary,$s->nomSary);
			}
			return $nomsary;
		}

		public function ConstructSary(){
			$sary = array();
			$query = $this->db->get('sary');
			
			foreach($query->result() as $s){
				$sary[$s->idObjet] = $this->getSaryByIdObject($s->idObjet);
			}
			return $sary;
		}
	}	
?>