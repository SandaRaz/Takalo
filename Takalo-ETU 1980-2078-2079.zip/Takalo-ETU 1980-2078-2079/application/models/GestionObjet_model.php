<?php 
	class GestionObjet_model extends CI_Model {
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function liste_de_mes_objets($idUtil){
			$query = $this->db->query("SELECT * FROM objet o join categorie c on o.idCategorie=c.idCategorie where o.etat=5 and o.idUtilisateur=".$idUtil);

			return $query->result();
		}

		public function get_last_Object(){
			$sql = "SELECT * FROM objet WHERE idObjet = (SELECT MAX(idObjet) FROM objet)";
			$query = $this->db->query($sql);
			return $query->row();
		}

		public function inserer_newObject($object,$postname){
			$query = $this->db->insert('objet',$object);
			$ligneinserer =  $this->db->affected_rows();

			$succes = 0;

			if($ligneinserer > 0){	// insertion sary
				$newObject = $this->get_last_Object();
				foreach ($this->uploadPics($postname) as $key) {
					$sary = array(
						'idSary' => null,
						'idObjet' => $newObject->idObjet,
						'nomSary' => $key
					);
					$query2 = $this->db->insert('sary',$sary);
					if($this->db->affected_rows() > 0){
						$succes++;
					}
				}
			}

			return $ligneinserer;
		}

		public function uploadPics($postname){
			$listes_sary = array();

			$target_dir = "assets/img/";
			foreach ($_FILES[$postname]['error'] as $key => $error) {
				if($error == UPLOAD_ERR_OK){
					$tmp_name = $_FILES[$postname]['tmp_name'][$key];
					$name = $_FILES[$postname]['name'][$key];
					$target_file = $target_dir . $name;
					if(move_uploaded_file($tmp_name, $target_file)){
						array_push($listes_sary, $name);
					}
				}
			}

			return $listes_sary;
		}

		public function supprimer_Object($idObjet){
			$sql = "UPDATE objet SET etat = 0 WHERE idObjet = '%d'";
			$sql = sprintf($sql,$idObjet);
			echo $sql;
			$this->db->query($sql);
			return $this->db->affected_rows();
		}

		public function prixplusmarge($prix , $marge){
			$ppm = $prix + ($prix * ($marge/100));
			return $ppm;
		}

		public function listeObjet_par_PrixEstimatif($idUtil, $prix , $marge){	//----- ?prix=100&marge=10 et ?prix=100&marge=2
			$limiteBas = $this->prixplusmarge($prix , -$marge);
			$limitehaut = $this->prixplusmarge($prix , $marge);

			$sql = "SELECT *,((o.prix*100)/%d)-100 difference FROM objet o JOIN categorie c ON o.idCategorie=c.idCategorie WHERE idUtilisateur != %d AND prix >= %d AND prix <= %d AND etat = 5";
			$sql = sprintf($sql , $prix ,  $idUtil , $limiteBas , $limitehaut);

			$query = $this->db->query($sql);
			return $query->result();
		}
	}
?>