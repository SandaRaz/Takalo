<?php 
	class Echange_model extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		//Prendre la liste des objets de l’utilisateur
		public function getObjetByIdUser($idUtilisateur)
		{
			$query = $this->db->get_where('objet','idUtilisateur'->$idUtilisateur);
            return $query->result();
		}
		
		
		//Prendre l’objet a demander grace a son id
        public function getObjetByIdObjet($idObjet)
		{
			$query = $this->db->query("SELECT * FROM objet where idObjet=".$idObjet);
            return $query->row();
		}

		//fonction pour ajouter echange dans la base
        public function Echanger($data) {
            $this->db->insert('echange', $data);
            return $this->db->insert_id();
        }

		public function getLastEchanger()
		{
			$last = $this->db->query("SELECT MAX(idEchange) max FROM echange");
			return $last->row();
		}

		public function changeDate()
		{
			$query = $this->db->query("UPDATE echange set daty=now() where idEchange=".$this->getLastEchanger()->max);

		}
		public function echanger2($idObjDem,$idObj2Rec){

	        $obj1 = $this->getObjetByIdObjet($idObjDem);
	        $obj2 = $this->getObjetByIdObjet($idObj2Rec);

			$data = array(
				'idEchange' => null,
				'idDemandeur' => $obj1->idUtilisateur,
				'idReceveur' => $obj2->idUtilisateur,
				'idObjetDemandeur' => $obj1->idObjet,
				'idObjetReceveur' => $obj2->idObjet,
	            'etat'=>1,
	            'daty'=>'now()'
			);

	        $this->Echanger($data);
	        $this->changeDate();

	    }

	    public function echangerPlusieurs($choix , $idObjet){
	        foreach ($choix as $idChoixObjet) {
	            $this->echanger2($idChoixObjet , $idObjet);
	        }
	    }

	}
?>