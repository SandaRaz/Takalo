<?php
	class Recherche_model extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}


		public function Rechercher($idUtil , $motcle , $idCategorie){
			$query = null;

			if($idCategorie < 0){		// -------- exemple -1 pour 'All' --------
				$sql1 = "SELECT * FROM objet o JOIN categorie c on o.idCategorie=c.idCategorie WHERE idUtilisateur != '%d' AND titre LIKE %s AND etat = 5";
				$sql1 = sprintf($sql1 , $idUtil , $this->db->escape("%".$motcle."%"));
				$query = $this->db->query($sql1);
			}else{
				$sql2 = "SELECT * FROM objet o JOIN categorie c on o.idCategorie=c.idCategorie WHERE idUtilisateur != '%d' AND titre LIKE %s AND o.idCategorie = '%d' AND etat = 5";
				$sql2 = sprintf($sql2 , $idUtil , $this->db->escape("%".$motcle."%") , $idCategorie);
				$query = $this->db->query($sql2);
			}

			$list = array();
			// foreach ($query->result() as $key) {
			// 	array_push($list, $key);
			// }
			return $query->result();
		}
	}
?>