<?php 
	class Statistiques_model extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function nombreUserInscrit(){
			$sql = "SELECT COUNT(idUtilisateur) nombre,now() dates from utilisateur";
			$query = $this->db->query($sql);
			return $query->row();
		}

		public function nombreEchangeEffectue(){
			$sql = "SELECT COUNT(idEchange) nombre,now() dates FROM echange WHERE etat = 10";
			$query = $this->db->query($sql);
			return $query->row();
		}

		public function addCategorie($data)
		{
			$this->db->insert('categorie', $data);
			return $this->db->insert_id();
		}
	}
?>