<?php 
	class Historique_model extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function historiqueEchangeById($idEchange){	// chaque echange retourne une liste composee de 2 objets
			$list = array();

			$sql1 = "SELECT e.idEchange,e.idDemandeur idProprietaire,u.nomUtilisateur nom,u.prenomUtilisateur prenom,e.idObjetReceveur idObjet,o.titre,o.description,e.etat,e.daty,o.prix FROM echange e,utilisateur u,objet o WHERE e.idDemandeur = u.idUtilisateur AND e.idObjetReceveur = o.idObjet AND e.idEchange = '%d'";
			$sql1 = sprintf($sql1 , $idEchange);
			//echo $sql1 . "</br>";
			$query1 = $this->db->query($sql1);
			array_push($list , $query1->row());
			
			/*		--------- RESULTAT DE CETTE REQUETTE ----------

				+-----------+----------------+------+--------+---------+-------+--------------+------+---------------------+
				| idEchange | idProprietaire | nom  | prenom | idObjet | titre | description  | etat | daty                |
				+-----------+----------------+------+--------+---------+-------+--------------+------+---------------------+
				|         1 |              1 | Raz  | Sanda  |       2 | gomme | marque Maped |   10 | 2023-02-08 00:50:23 |
				+-----------+----------------+------+--------+---------+-------+--------------+------+---------------------+
			*/

			$sql2 = "SELECT e.idEchange,e.idReceveur idProprietaire,u.nomUtilisateur nom,u.prenomUtilisateur prenom,e.idObjetDemandeur idObjet,o.titre,o.description,e.etat,e.daty,o.prix FROM echange e,utilisateur u,objet o WHERE e.idReceveur = u.idUtilisateur AND e.idObjetDemandeur = o.idObjet AND e.idEchange = '%d'";
			$sql2 = sprintf($sql2 , $idEchange);
			$query2 = $this->db->query($sql2);
			array_push($list , $query2->row());

			/*		--------- RESULTAT DE CETTE REQUETTE ----------

				+-----------+----------------+------+---------+---------+-------+--------------+------+---------------------+
				| idEchange | idProprietaire | nom  | prenom  | idObjet | titre | description  | etat | daty                |
				+-----------+----------------+------+---------+---------+-------+--------------+------+---------------------+
				|         1 |              2 | Raz  | Toavina |       1 | stylo | couleur bleu |   10 | 2023-02-08 00:50:23 |
				+-----------+----------------+------+---------+---------+-------+--------------+------+---------------------+

			*/

			return $list;
		}

		public function getAllEchange(){
			$query = $this->db->get('echange');
			$list = array();
			foreach ($query->result() as $key) {
				array_push($list , $key);
			}
        	return $list;
		}

		public function historiquesDetaillees(){
			$lists = array();
			foreach ($this->getAllEchange() as $key) {
				//echo $key->idEchange.">>>".$this->historiqueEchangeById($key->idEchange)[0]->titre;
				array_push($lists , $this->historiqueEchangeById($key->idEchange)[0]);
				array_push($lists , $this->historiqueEchangeById($key->idEchange)[1]);
			}
			return $lists;
		}
	}
?>