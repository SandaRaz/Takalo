<?php

class LoginBack_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function checkAdmin($email,$password)
    {
        $query = $this->db->get_where('admin',array('email'=>$email,'password'=>$password));
        $row = $query->row();
        
        if($row==null)
        {
            return false;
        }
        return true;
    }

    public function get_admin_by_emailAndPassword($email,$password)
    {
        $row = null;
        if($this->checkAdmin($email,$password)==true)
        {
            $query = $this->db->get_where('admin',array('email'=>$email,'password'=>$password));
            $row = $query->row();
        }
        return $row;
    }

    public function get_admins() {
        $query = $this->db->get('admin');
        return $query->result();
    }

    public function get_admin_by_id($id) {
        $query = $this->db->get_where('admin', array('idAdmin' => $id));
        return $query->row();
    }

    public function add_admin($data) {
        $this->db->insert('admin', $data);
        return $this->db->insert_id();
    }

    public function update_admin($id, $data) {
        $this->db->update('admin', $data, array('idAdmin' => $id));
    }

    public function delete_admin($id) {
        $this->db->delete('admin', array('idAdmin' => $id));
    }

}

?>