<?php 
	class LoginFront_model extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
				
		public function loginValide($mail,$pwd){
			$query = $this->db->get_where('utilisateur', array('email' => $mail,'password' => $pwd));
			return $query->row();
		}

		public function insererNewUtilisateur($infos){
			$query = $this->db->insert('utilisateur',$infos);
			return $this->db->affected_rows();
		}

		public function emailUnique($mail){
			$query = $this->db->get_where('utilisateur',array('email' => $mail));
			if($query->row() == null){
				return true;
			}else{
				return false;
			}
		}
	}
?>