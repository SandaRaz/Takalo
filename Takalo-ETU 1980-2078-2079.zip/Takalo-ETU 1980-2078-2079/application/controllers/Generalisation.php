<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Generalisation extends CI_Controller {
    

}
