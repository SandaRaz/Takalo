<?php 
	defined('BASEPATH') or exit('No direct script access allowed');

	class GestionObjet_controller extends CI_Controller {
		public function __construct(){
			parent::__construct();
			$this->load->model('GestionObjet_model');
			$this->load->helper('url');
		}

		public function index()
		{
			$this->load->model('GestionObjet_model');
			$this->load->model('AutreUserObjet_model');
			
			$listesCateg = array();
			$listesCateg = $this->AutreUserObjet_model->listesCategories();

			$this->load->model('AutreUserObjet_model');
			
			
			
			session_start();
			if(isset($_SESSION['idUser']))
			{
				$idUtil = $_SESSION['idUser'];
				$data=array(
					'allObjet' => $this->GestionObjet_model->liste_de_mes_objets($idUtil),
					'listeCateg'=>$listesCateg,
					'sary'=>$this->AutreUserObjet_model->ConstructSary()
				);
				
				$this->load->view('GestionObjet_view',$data);
			}else{
				echo "non-user";
			}
	
		}

		public function lister_lesObjets(){
			session_start();
			$idUtil = $_SESSION['idUser'];
			$listes = array();

			$listes = $this->GestionObjet_model->liste_de_mes_objets($idUtil);
			
			$this->load->view('MBOLA_TSISY_PAGE',$listes);
			redirect(base_url('../MBOLA_TSISY_PAGE'));
		}

		public function inserer_new_Object(){
			session_start();
			$idUtil = $_SESSION['idUser'];

			$object = array(
				'idObjet' => null,
				'titre' => $this->input->post("titre"),
				'description' => $this->input->post("description"),
				'prix' => $this->input->post("prix"),
				'idCategorie' => $this->input->post("idCategorie"),
				'idUtilisateur' => $idUtil,
				'etat' => 5, // par defaut 5 , 0 : supprimer
			);
			$sary = $this->input->post('sary');
			
			$ligneinserer = $this->GestionObjet_model->inserer_newObject($object,"sary");

			if($ligneinserer == 0){		// erreur dans l'insertion
				
				// $this->load->view('MBOLA_TSISY_PAGE');
				redirect(base_url('../GestionObjet_controller'));
				
			}else{
				redirect(base_url('../GestionObjet_controller'));
				// $this->load->view('MBOLA_TSISY_PAGE');
				// redirect(base_url('MBOLA_TSISY_PAGE'));
			}
		}

		public function supprimer_Object(){
			$idObjet = $this->input->get("idObjet");
			$nbsuppr = $this->GestionObjet_model->supprimer_Object($idObjet);
			
			session_start();
			
			$idUtil = $_SESSION['idUser'];
			$data['allObjet'] = $this->GestionObjet_model->liste_de_mes_objets($idUtil);
			$this->load->view('GestionObjet_view',$data);
			redirect(base_url('../GestionObjet_controller'));
		}
		public function listeEstimatif_Objet(){
			$this->load->model('AutreUserObjet_model');
			$this->load->model('GestionObjet_model');

			session_start();

			$idUtil = $_SESSION['idUser'];
			$prix = $this->input->get("prix");
			$marge = $this->input->get("marge");

			$objetEstim = array();
			$objetEstim = $this->GestionObjet_model->listeObjet_par_PrixEstimatif($idUtil,$prix,$marge);

			$data['allObjet'] = $objetEstim;
			$data['sary']=$this->AutreUserObjet_model->ConstructSary();
			$data['categorie'] = $this->AutreUserObjet_model->listesCategories();

			$this->load->view('Marge_view',$data);
		}
	}
?>