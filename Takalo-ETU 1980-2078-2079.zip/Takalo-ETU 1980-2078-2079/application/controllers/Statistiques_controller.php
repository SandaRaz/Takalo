<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Statistiques_controller extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('Statistiques_model');
		}

		public function index()
		{
			$this->load->model('Statistiques_model');
			$data = array();
			$users = $this->Statistiques_model->nombreUserInscrit();
			$echanges = $this->Statistiques_model->nombreEchangeEffectue();

			$data['nbUsers'] = $users;
			$data['nbEchanges'] = $echanges;

			$this->load->view('Statistique_view',$data);
		}


		public function NombreUserInscrit(){
			/* -------------- DONNEE RETROURNEE -----------

			+--------+---------------------+
			| nombre | dates               |
			+--------+---------------------+
			|      2 | 2023-02-08 08:10:06 |
			+--------+---------------------+

			*/
			$nombreinscrit['nombreinscrit'] = $this->Statistiques_model->nombreUserInscrit();

			$this->load->view('MBOLA_TSISY_PAGE' , $nombreinscrit);
			redirect(base_url('MBOLA_TSISY_PAGE'));
		
		}

		public function NombreEchange(){
			/* -------------- DONNEE RETROURNEE -----------

			+--------+---------------------+
			| nombre | dates               |
			+--------+---------------------+
			|      1 | 2023-02-08 08:13:31 |
			+--------+---------------------+

			*/
			$nombreechange['nombreechange'] = $this->Statistiques_model->nombreEchangeEffectue();

			$this->load->view('MBOLA_TSISY_PAGE' , $nombreechange);
			redirect(base_url('MBOLA_TSISY_PAGE'));
		
		}
		public function addCategorie(){
			$this->load->model('Statistiques_model');
			$nomCateg = $this->input->post('categorie');

			$data = array(
				'idCategorie'=>null,
				'nomCategorie'=>$nomCateg
			);


			$this->Statistiques_model->addCategorie($data);

			$this->load->helper('url');
			
			redirect(base_url("../Statistiques_controller/"));
		
		}
		public function deco(){
			$this->load->helper('url');
			session_start();
			session_destroy();
	
			redirect("../LoginBack_controller");
		}

	} 
?>