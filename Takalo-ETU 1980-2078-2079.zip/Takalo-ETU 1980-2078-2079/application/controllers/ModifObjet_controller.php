<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModifObjet_controller extends CI_Controller {
    public function __constuct()
    {
        parent::__constuct();
        
    }

    public function index($idObj='')
    {
        $this->load->model('ModifObjet_model');
        $res = $this->ModifObjet_model->getObjById($idObj);

        $data = array(
            'allCategorie'=>$this->ModifObjet_model->getAllCategorie(),
            'obj'=>$this->ModifObjet_model->getObjById($idObj)
        );

        $this->load->view('ModifObjet_view',$data);
    }
    public function modifier()
    {
        $this->load->model('ModifObjet_model');
        $this->load->helper('url');
		$this->load->database();

        $id = $this->input->post("idObjet");
       
		$infos = array(
			'titre' => $this->input->post("titre"),
			'Description' => $this->input->post("description"),
			'prix' => $this->input->post("prix"),
			'idCategorie' => $this->input->post("idCategorie"),
		);

        $this->ModifObjet_model->update_objet($id,$infos);

        session_start();
		$idUtil = $_SESSION['idUser'];
		$data['allObjet'] = $this->ModifObjet_model->liste_de_mes_objets($idUtil);
		$this->load->view('GestionObjet_view',$data);
		redirect(base_url('../GestionObjet_controller'));	
    }
 
}
