<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Recherche_controller extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('Recherche_model');
		}

		public function rechercher(){
			session_start();
			$this->load->model('AutreUserObjet_model');
			$this->load->model('Recherche_model');
			$idUtil = $_SESSION['idUser'];
			$motcle = $this->input->post("motcle");
			$idCateg = $this->input->post("idcategorie");

			$resultRecherche = array();
			$resultRecherche = $this->Recherche_model->Rechercher($idUtil , $motcle , $idCateg);
			
			
			
			if(isset($_SESSION['idUser']))
			{
				$idUtil = $_SESSION['idUser'];
				$file = array();
				$data['sary']=$this->AutreUserObjet_model->ConstructSary();
				$data['categorie'] = $this->AutreUserObjet_model->listesCategories();
				$data['allObjet'] = $resultRecherche;
			}
			

			$this->load->helper('url');

			//$this->load->view('AutreUserObjet_view',$data);
			redirect(base_url("../AutreUserObjet_controller/res?idMotCle=".$motcle."&idCateg=".$idCateg));
			

		}
	}