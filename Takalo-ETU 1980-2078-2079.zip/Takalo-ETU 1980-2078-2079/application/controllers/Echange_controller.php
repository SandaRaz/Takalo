<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Echange_controller extends CI_Controller {
    public function __constuct()
    {
        parent::__constuct();
        $this->load->model('Echange_model');
        $this->load->database();

    }

    public function index()
    {
        $this->load->model('GestionObjet_model');
        $this->load->model('AutreUserObjet_model');
		
        $idObj2 = $this->input->get('idObjet');
        session_start();
        if(isset($_SESSION['idUser']))
        {
            $idUtil = $_SESSION['idUser'];
            $data = array(
                'allObjet'=>$this->GestionObjet_model->liste_de_mes_objets($idUtil),
                'idObj2'=>$idObj2
            );
            $data['sary']=$this->AutreUserObjet_model->ConstructSary();
            $this->load->view('Echange_view',$data);
        }else{
            echo "non-user";
        }
    }
    public function multiple()
    {
        $this->load->model('GestionObjet_model');
        $this->load->model('AutreUserObjet_model');
		
        $idObj2 = $this->input->get('idObjet');
        session_start();
        if(isset($_SESSION['idUser']))
        {
            $idUtil = $_SESSION['idUser'];
            $data = array(
                'allObjet'=>$this->GestionObjet_model->liste_de_mes_objets($idUtil),
                'idObj2'=>$idObj2
            );
            $data['sary']=$this->AutreUserObjet_model->ConstructSary();
            $this->load->view('EchangeMultiple_view',$data);
        }else{
            echo "non-user";
        }
    }

    public function echanger($idObj1='',$idObj2='')
    {
        $this->load->database();
        $this->load->model('Echange_model');
		
        $this->load->helper('url');
		

        $obj1 = $this->Echange_model->getObjetByIdObjet($idObj1);
        $obj2 = $this->Echange_model->getObjetByIdObjet($idObj2);

		$data = array(
			'idDemandeur' => $obj1->idUtilisateur,
			'idReceveur' => $obj2->idUtilisateur,
			'idObjetDemandeur' => $obj1->idObjet,
			'idObjetReceveur' => $obj2->idObjet,
            'etat'=>1,
            'daty'=>'now()'
		);
        $this->Echange_model->Echanger($data);
        $this->Echange_model->changeDate();


        redirect(base_url('../AutreUserObjet_controller'));
        

    }
    public function echangerPlusieur(){

        $this->load->helper('url');
        $this->load->model('Echange_model');

        $objectsUtilisateurs = array();

        $objectsUtilisateurs = $this->input->post("choix"); // tableau[] id des choix du demandeur

        $idObjetAutreUser = $this->input->post("idObjet");  // id objet d'un autre utilisateur

        $this->Echange_model->echangerPlusieurs($objectsUtilisateurs , $idObjetAutreUser);

        redirect(base_url('../AutreUserObjet_controller'));
        
    }
   
}
