<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	 
	class Resultat_controller extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('AutreUserObjet_model');
		}

		
		public function index()
		{
			$this->load->model('AutreUserObjet_model');
            $this->load->model('Recherche_model');
			session_start();
           
            $motcle = $this->input->post('motcle');
            $idCateg = $this->input->post('idcategorie');
           
			if(isset($_SESSION['idUser']))
			{
				$idUtil = $_SESSION['idUser'];
				$file = array();
				$data['sary']=$this->AutreUserObjet_model->ConstructSary();
				$data['categorie'] = $this->AutreUserObjet_model->listesCategories();
                $resultRecherche = $this->Recherche_model->Rechercher($idUtil , $motcle , $idCateg);
                $data['allObjet']=$resultRecherche;
			}
				
			$this->load->view('Resultat_view',$data);
            //redirect(base_url("../Resultat_controller"));
		}
    }
?>