<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginBack_controller extends CI_Controller {
    public function __constuct()
    {
        parent::__constuct();
        $this->load->model('LoginBack_model');
    }

    public function index()
    {
        $this->load->view('LoginBack_view');
    }
    public function checkLogin()
    {
        $this->load->library('session');
        $this->load->model('LoginBack_model');
        $this->load->helper('url');
        $this->load->database();

        $email =  $this->input->post('email');
        $password = $this->input->post('password');

        if($this->LoginBack_model->checkAdmin($email,$password)==true)
        {
            $admin = $this->LoginBack_model->get_admin_by_emailAndPassword($email,$password);
            $this->session->idAdmin = $admin->idAdmin;
            $this->load->view('Statistique_view');
            redirect(base_url('../Statistiques_controller'));
        }
        else{
            $this->session->errorLogin = "errorLogin";
            $this->load->view('LoginBack_view');
            redirect(base_url('../LoginBack_controller'));
        }

    }
 
}
