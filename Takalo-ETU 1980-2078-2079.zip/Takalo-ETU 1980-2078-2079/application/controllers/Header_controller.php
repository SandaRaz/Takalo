<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Header_controller extends CI_Controller {
    public function __constuct()
    {
        parent::__constuct();
    }

    public function index()
    {
        $this->load->view('LoginFront_view');
    }
    public function deco()
    {
        $this->load->helper('url');
        session_start();
        session_destroy();

        redirect("../LoginFront_controller");
    }
 
}
?>