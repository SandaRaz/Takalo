<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');

	class DemandeEchange_controller extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('DemandeEchange_model');
			$this->load->model('Echange_model');
		}

	
		public function index(){
			session_start();
			$this->load->model('Echange_model');
			$this->load->model('AutreUserObjet_model');
	
			$idUtil = $_SESSION['idUser'];

			$listesDemandes = array();
			$listesDemandes = $this->DemandeEchange_model->listeDemandeEchange($idUtil);

			$list['temp'] = $listesDemandes;

			$data['listeDemande'] = array();
			foreach($listesDemandes as $liste){
				array_push($data['listeDemande'],
					array(
						'idEchange'=>$liste->idEchange,
						'objetDemandeur'=>$this->Echange_model->getObjetByIdObjet($liste->idObjetDemandeur),
						'objetReceveur'=>$this->Echange_model->getObjetByIdObjet($liste->idObjetReceveur),
					)
				);
			}
			$data['sary']=$this->AutreUserObjet_model->ConstructSary();
			$this->load->view('DemandeEchange_view', $data);
		}

		public function EchangeAccepte(){
			$this->load->helper('url');
			$idEchange = $this->input->get("idEchange");

			$this->DemandeEchange_model->accepterEchange($idEchange);

			echo "Vous avez accepté la demande";
			redirect(base_url('../DemandeEchange_controller'));
		}

		public function EchangeRefuse(){
			$this->load->helper('url');
			$idEchange = $this->input->get("idEchange");

			$ligneaffectee = $this->DemandeEchange_model->refuserEchange($idEchange);


			echo "Vous avez refusé la demande";
			redirect(base_url('../DemandeEchange_controller'));
		}
	}

?>