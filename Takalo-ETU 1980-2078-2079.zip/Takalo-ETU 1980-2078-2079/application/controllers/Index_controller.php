<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index_controller extends CI_Controller {
    public function __constuct()
    {
        parent::__constuct();
    }

    public function index()
    {
        $this->load->view('Index_view');
    }
 
}
?>