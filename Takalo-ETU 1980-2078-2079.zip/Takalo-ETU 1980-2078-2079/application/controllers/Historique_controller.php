<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	 
	class Historique_controller extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('Historique_model');
		}

		public function index(){
			$this->load->model('Historique_model');
			$this->load->model('AutreUserObjet_model');

			$historiques = array();
			$historiques = $this->Historique_model->historiquesDetaillees();
			$list['historique'] = $historiques;
			$list['sary']=$this->AutreUserObjet_model->ConstructSary();
			$this->load->view('HistoriqueEchange_view' , $list);
		}
	}
?>