<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
    public function __constuct()
    {
        parent::__constuct();
        $this->load->model('User_model');
    }
	public function afficherLogin()
	{
		$this->load->view('login');
	}
    public function checkLogin()
    {
        $this->load->library('session');
        
        $username = $this->input->post("username");
        $password = $this->input->post("password");

        $this->load->database();
        $this->load->model('User_model');
        $data = $this->User_model->get_users();

        foreach($data as $u)
        {
            echo $u->email;
        }
        
        //$query = $this->db->get_where('user',array('id'=>2));

        // $data = array('id'=>null,'nom'=>"huhu",'prenom'=>"haha",'email'=>'huhu@haha.com','password'=>"haha",'genre'=>"femelle");

        // $this->db->insert('user',$data);

        // $result = $query->result();
        
        // foreach ($result as $resultat) {
        //     echo $resultat->id . " " . $resultat->nom . "<br>";
        //   }
        // if($username=="admin" && $password=="1234")
        // {
        //     $this->session->username = $username;
        //     $this->session->password = $password;

        //     $this->load->view('accueil');
        // }else{
        //     $this->load->view('login');
        // }
    }
 
}
