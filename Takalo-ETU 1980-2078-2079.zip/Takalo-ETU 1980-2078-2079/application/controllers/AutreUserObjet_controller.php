<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	 
	class AutreUserObjet_controller extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('AutreUserObjet_model');
		}

		
		public function index()
		{
			$this->load->model('AutreUserObjet_model');
			session_start();
			if(isset($_SESSION['idUser']))
			{
				$idUtil = $_SESSION['idUser'];
				$file = array();
				$data['allObjet'] = $this->AutreUserObjet_model->AutresUserObjet($idUtil);
				$data['sary']=$this->AutreUserObjet_model->ConstructSary();
				$data['categorie'] = $this->AutreUserObjet_model->listesCategories();;
			}
				
			$this->load->view('AutreUserObjet_view',$data);
		}


		public function index2($data='')
		{
			$this->load->model('AutreUserObjet_model');
			$this->load->view('AutreUserObjet_view',$data);
			
		}

		public function res()
		{
			session_start();
			$this->load->model('Recherche_model');
			$this->load->model('AutreUserObjet_model');
			$this->load->helper('url');
			$motcle = $this->input->get('motcle');
			$idCateg = $this->input->get('idCateg');

			
			if(isset($_SESSION['idUser']))
			{

				$idUtil = $_SESSION['idUser'];
				$resultRecherche = array();

				$resultRecherche = $this->Recherche_model->Rechercher($idUtil , $motcle , $idCateg);
			
				$file = array();
				$data['sary']=$this->AutreUserObjet_model->ConstructSary();
				$data['categorie'] = $this->AutreUserObjet_model->listesCategories();
				$data['allObjet'] = $resultRecherche;
				
			}
			$this->load->view('AutreUserObjet_view',$data);
			redirect(base_url('../AutreUserObjet_controller/index2/'.$data));
			
		}

		public function lister_Categories(){
			$listesCateg = array();
			$listesCateg = $this->AutreUserObjet_model->listesCategories();

			$list['listesCateg'] = $listesCateg;

			$this->load->view('MBOLA_TSISY_PAGE',$list);
			redirect(base_url('../MBOLA_TSISY_PAGE'));
		}

		public function listesObjets_AutresUser(){
			$idCateg = $this->db->get("idCategorie");

			$listesObjAutres = $this->AutreUserObjet_model->listesAutreUserObjet($idCateg);

			$list['listesObjAutres'] = $listesObjAutres;

			$this->load->view('MBOLA_TSISY_PAGE',$list);
			redirect(base_url('../MBOLA_TSISY_PAGE'));
		}
	}
?>