<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	 
	class AjouterObjet_controller extends CI_Controller{
		public function __construct(){
			parent::__construct();
			
		}

		public function index()
		{
			
		}

		public function lister_Categories(){
            $this->load->model('AutreUserObjet_model');
			$listesCateg = array();
			$listesCateg = $this->AutreUserObjet_model->listesCategories();

			$list['listesCateg'] = $listesCateg;

			$this->load->view('MBOLA_TSISY_PAGE',$list);
			redirect(base_url('../MBOLA_TSISY_PAGE'));
		}

		public function listesObjets_AutresUser(){
			$idCateg = $this->db->get("idCategorie");

			$listesObjAutres = $this->AutreUserObjet_model->listesAutreUserObjet($idCateg);

			$list['listesObjAutres'] = $listesObjAutres;

			$this->load->view('MBOLA_TSISY_PAGE',$list);
			redirect(base_url('../MBOLA_TSISY_PAGE'));
		}
	}
?>