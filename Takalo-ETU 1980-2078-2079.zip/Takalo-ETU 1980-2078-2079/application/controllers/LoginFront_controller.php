<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');

	class LoginFront_controller extends CI_Controller {
		public function __construct(){
			parent::__construct();
			$this->load->model('LoginFront_model');
		}

		public function index()
		{
			$this->load->view('LoginFront_view');	
		}
		public function afficherInscription()
		{
			$this->load->view('SignUpFront_view');
		}
		public function checkLogin(){
			//$this->load->library('session');
			$this->load->model('LoginFront_model');
			$this->load->helper('url');
			$this->load->database();

			$mail = $this->input->post("email");
			$pwd = $this->input->post("password");

			$utilisateur = $this->LoginFront_model->loginValide($mail, $pwd);
			
			if(empty($utilisateur)){
				$data['erreur'] = true;
				$this->load->view('LoginFront_view',$data);
				redirect(base_url('../LoginFront_controller'));
			}else{
				session_start();
				$_SESSION['idUser'] = $utilisateur->idUtilisateur;
				$this->load->view('AutreUserObjet_view');
				redirect(base_url('../AutreUserObjet_controller'));
			}
		
		}

		public function inscription(){

			$this->load->model('LoginFront_model');
			$this->load->helper('url');
			$this->load->database();
			$infos = array(
				'idUtilisateur'=>null,
				'nomUtilisateur' => $this->input->post("nom"),
				'prenomUtilisateur' => $this->input->post("prenom"),
				'email' => $this->input->post("email"),
				'password' => $this->input->post("mdp")
			);
			
			if($this->LoginFront_model->emailUnique($infos['email'])){

				$colonneAffectee = $this->LoginFront_model->insererNewUtilisateur($infos);

				if($colonneAffectee == 0){
					$this->load->view('LoginFront_view');
					redirect(base_url('../LoginFront_controller'));
				}else{
					$this->load->view('LoginFront_view');
					redirect(base_url('../LoginFront_controller'));
				}
			}else{
				$this->load->view('LoginFront_view');
				redirect(base_url('../LoginFront_controller'));
			}			
		}
	}
?>