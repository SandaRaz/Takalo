<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
    />
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
  </head>
  <body>
    <nav
      class="navbar navbar-light navbar-expand-lg navigation-clean-search"
      style="
        color: var(--bs-purple);
        background: var(--bs-gray-200);
        border-color: var(--bs-indigo);
        --bs-body-bg: var(--bs-blue);
      "
    >
      <div class="container">
        <a class="navbar-brand" href="#" style="color: rgb(11, 1, 28)"
          >TAKALOTAKALO</a
        ><button
          data-bs-toggle="collapse"
          class="navbar-toggler"
          data-bs-target="#navcol-1"
        >
          <span class="visually-hidden">Toggle navigation</span
          ><span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navcol-1">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" href="#">Home</a>
            </li>
            <li class="nav-item"><a class="nav-link" href="#">Demande</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Liste</a></li>
          </ul>
          <form class="me-auto search-form" target="_self">
            <div class="d-flex align-items-center">
              <label class="form-label d-flex mb-0" for="search-field"
                ><i class="fa fa-search"></i></label
              ><input
                class="form-control search-field"
                type="search"
                id="search-field"
                name="search"
              />
            </div>
          </form>
          <a class="btn btn-light action-button" role="button" href="#"
            >Deconnexion</a
          >
        </div>
      </div>
    </nav>
    <section class="features-blue" style="height: 850.6px">
      <div class="container" style="border-radius: 45px">
        <div class="intro" style="margin-top: 3px">
          <h2
            class="text-center"
            style="
              transform: skew(0deg);
              font-size: 35.1px;
              line-height: 45.1px;
              letter-spacing: 3px;
              font-style: italic;
            "
          >
            Statistique
          </h2>
          <p class="text-center"></p>
        </div>
        <div
          class="row features"
          style="
            margin-right: -15px;
            margin-top: 136px;
            margin-bottom: -14px;
            width: 979px;
            margin-left: 70px;
          "
        >
          <div
            class="col-sm-6 col-md-4 item"
            style="
              padding-left: 141px;
              padding-bottom: 0px;
              padding-top: 26px;
              border-radius: 300px;
              border-style: solid;
              border-top-width: 2px;
              height: 148px;
              width: 313.3px;
            "
          >
            <i class="fa fa-list-alt icon"></i>
            <h3 class="name">Echange</h3>
            <p
              class="description"
              style="
                opacity: 71;
                filter: brightness(6%) contrast(200%) grayscale(77%)
                  hue-rotate(144deg) sepia(49%);
                height: 27.5px;
                --bs-body-font-size: 21rem;
                --bs-body-font-weight: bold;
                --bs-body-color: var(--bs-gray-200);
                border-color: var(--bs-gray-900);
                margin-left: -10px;
                margin-top: -10px;
                font-size: 52px;
                padding-top: 0px;
              "
            >
              46
            </p>
          </div>
          <div
            class="col-sm-6 col-md-4 item"
            style="
              margin-left: 305px;
              padding-top: 22px;
              border-top-style: solid;
              border-radius: 300px;
              width: 327px;
              height: 163px;
              padding-right: 69px;
              padding-left: 141px;
              padding-bottom: 0px;
              font-size: 51px;
              line-height: 55.5px;
              font-weight: bold;
              color: var(--bs-white);
            "
          >
            <i class="fa fa-plane icon" style="padding-left: 10px"></i>
            <h3 class="name">Client</h3>
            <p
              class="description"
              style="
                --bs-body-font-size: 25rem;
                font-size: 52px;
                padding-right: 77px;
                padding-bottom: 1px;
                padding-left: -114px;
                padding-top: 5px;
                filter: brightness(200%) contrast(200%) grayscale(40%);
              "
            >
              67
            </p>
          </div>
        </div>
      </div>
      <section
        class="newsletter-subscribe"
        style="
          background: rgba(233, 236, 239, 0);
          border-top: 1px solid var(--bs-gray-200);
          margin-top: 200px;
        "
      >
        <div class="container">
          <div class="intro">
            <h2
              class="text-center"
              style="
                font-style: italic;
                background: rgba(248, 249, 250, 0);
                color: var(--bs-white);
              "
            >
              Ajouter Categorie
            </h2>
          </div>
          <form class="d-flex justify-content-center flex-wrap" method="post">
            <div class="mb-3">
              <input
                class="form-control"
                type="email"
                name="email"
                placeholder="Categorie"
              />
            </div>
            <div class="mb-3">
              <button class="btn btn-primary" type="submit">Ajouter</button>
            </div>
          </form>
        </div>
      </section>
      <div></div>
    </section>
    <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvas-1">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title">Offcanvas Title</h5>
        <button
          type="button"
          class="btn-close text-reset"
          data-bs-dismiss="offcanvas"
          aria-label="Close"
        ></button>
      </div>
      <div class="offcanvas-body">
        <p>Offcanvas Paragraph</p>
        <button
          class="btn btn-primary"
          type="button"
          data-bs-dismiss="offcanvas"
        >
          Close
        </button>
      </div>
    </div>
    <div class="toast fade hide" role="alert" id="toast-1">
      <div class="toast-header">
        <img class="me-2" /><strong class="me-auto">Title</strong
        ><small>10 min ago</small
        ><button
          class="btn-close ms-2 mb-1 close"
          data-bs-dismiss="toast"
        ></button>
      </div>
      <div class="toast-body" role="alert">
        <p>
          Nullam id dolor id nibh ultricies vehicula ut id elit. Cras justo
          odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi
          porta gravida at eget metus.
        </p>
      </div>
    </div>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/script.min.js"></script>
  </body>ù
  <?php include('footer.php'); ?>
</html>
