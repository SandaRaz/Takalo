<?php 
    $this->load->model('Echange_model');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>Demande d'echange</title>
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/styles.min.css">
    </head>
    <body>
        <section class="projects-horizontal">
            <?php include('header_view.php'); ?>
            <div class="container">
                        <div class="intro">
                            <h2 class="text-center"> Les Objets proposés par d'autres utilisateur.</h2>
                            <p class="text-center"></p>
                            </div>
                            <div class="row projects">
                            <?php foreach($listeDemande as $all) { ?>
                                    <div class="col-sm-6 item">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-5">
                                                <a href="#">
                                                    <img class="img-fluid" src="assets/img/<?php echo $sary[$all['objetDemandeur']->idObjet][0]; ?>">
                                                    </a>
                                            </div>
                                            <div class="col">
                                                <h3 class="name"><?php echo $all['objetDemandeur']->titre; ?></h3>
                                                <p class="description"><?php echo $all['objetDemandeur']->description; ?>&nbsp;</p>
                                                <p class="prix">Prix Estimé:   <?php echo $all['objetDemandeur']->prix; ?>&nbsp;</p>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="col-sm-6 item">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-5">
                                                <a href="#">
                                                    <img class="img-fluid" src="assets/img/<?php echo $sary[$all['objetReceveur']->idObjet][0]; ?>">
                                                </a>
                                            </div>
                                            <div class="col">
                                                <h3 class="name"><?php echo $all['objetReceveur']->titre; ?></h3>
                                                <p class="description"><?php echo $all['objetReceveur']->description; ?>&nbsp;</p>
                                                <p class="prix">Prix Estimé:   <?php echo $all['objetReceveur']->prix; ?>&nbsp;</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="btn-demande">
                                    <a href="DemandeEchange_controller/EchangeAccepte?idEchange=<?php echo $all['idEchange']; ?>"><button class="btn btn-primary" type="button">Accepter</button></a>
                                    <a href="DemandeEchange_controller/EchangeRefuse?idEchange=<?php echo $all['idEchange']; ?>"><button class="btn btn-primary" type="button">Refuser</button></a>
                                    </div>
                            <?php } ?>   

                        </div>
                    </div>
            </div>
        </section>
 <script src="assets/bootstrap/js/bootstrap.min.js">
 </script>
  <?php include('footer.php'); ?>
  </body>
     </html>