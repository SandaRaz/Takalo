var btn = document.getElementById("btn");
btn.onclick = function(){
    var div = document.getElementById("plus");
    var inp = document.createElement("input");
    inp.name = "sary";
    inp.id ="select-modif";
    inp.type = "file";
    div.appendChild(inp);
}
