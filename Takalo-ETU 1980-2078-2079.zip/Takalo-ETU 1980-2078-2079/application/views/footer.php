<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
    />
    <title></title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css" />
    <link rel="stylesheet" href="assets/footer/assets/css/foot.css" />
  </head>
  <body>
    <footer class="footer-dark">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-md-3 item">
            <h3>Apropos du site</h3>
            <ul>
              <li><a href="#">Web site</a></li>
              <li><a href="#">Echange</a></li>
              <li><a href="#">Qualite</a></li>
            </ul>
          </div>
          <div class="col-sm-6 col-md-3 item">
            <h3>Numero</h3>
            <ul>
              <li>ETU 001980</a></li>
              <li>ETU 002078</li>
              <li>ETU 002079</li>
            </ul>
          </div>
          <div class="col-md-6 item text">
            <h3>Promoteur</h3>
            <p>Rahajarison Rianala Fitiavana&nbsp;</p>
            <p>Razakarivony Andriatahiry Toavina</p>
            <p>Razanajatovo Sanda</p>
          </div>
          <div class="col item social">
            <a href="#"><i class="icon ion-social-facebook"></i></a
            ><a href="#"><i class="icon ion-social-twitter"></i></a
            ><a href="#"><i class="icon ion-social-snapchat"></i></a
            ><a href="#"><i class="icon ion-social-instagram"></i></a>
          </div>
        </div>
        <p class="copyright">Company Name © 2023</p>
      </div>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
