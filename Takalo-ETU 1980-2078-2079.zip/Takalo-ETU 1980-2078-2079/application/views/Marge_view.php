<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>Objets dans l'intervalle</title>
        <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/fonts/font-awesome.min.css">
        <link rel="stylesheet" href="../assets/css/styles.min.css">
    </head>
    <body>
       
        <div class="body">
        <section class="projects-horizontal">
        <?php include('header_view.php'); ?>
            <div class="container">
                            <div class="row projects" style="margin-top:70px">
                            <?php foreach($allObjet as $all) { ?>
                                    <div class="col-sm-6 item">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-5">
                                                <a href="#">
                                                    <img class="img-fluid" src="../assets/img/<?php echo $sary[$all->idObjet][0]; ?>">
                                                </a>
                                            </div>
                                            <div class="col">
                                                <h3 class="name"><?php echo $all->titre; ?></h3>
                                                <p class="description"><?php echo $all->description; ?>&nbsp;</p>
                                                <p class="prix">Prix Estimé:   <?php echo $all->prix; ?>&nbsp;</p>
                                                <p class="categorie">Categorie:   <?php echo $all->nomCategorie; ?>&nbsp;</p>
                                                <p class="diff">Difference:   <?php echo $all->difference; ?>%&nbsp;</p>
                                                <a href="../Echange_controller?idObjet=<?php echo $all->idObjet; ?>"><button class="btn btn-primary" type="button">Demande d'echange</button></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>   
                                </div>
                             </div>
                     </div>
            </div>
        </section>
 <script src="assets/bootstrap/js/bootstrap.min.js">
 </script>
 </div>
  </body>
   <?php include('footer.php'); ?>
     </html>