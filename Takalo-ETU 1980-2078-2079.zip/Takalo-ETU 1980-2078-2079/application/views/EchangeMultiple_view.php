<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>Echange</title>
        <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/fonts/font-awesome.min.css">
        <link rel="stylesheet" href="../assets/css/styles.min.css">
    </head>
    <body>
        <section class="projects-horizontal">
            <div class="container">                      
                <div class="intro">
                        <h2 class="text-center">Vos Objets</h2>
                        <p class="text-center">Choisissez des objet a echanger</p>
                </div>
                <div class="row projects">
                <form method="post" action="../Echange_controller/echangerPlusieur">
                    <input type="hidden" name="idObjet" value=<?php echo $idObj2; ?>>
                    <?php foreach($allObjet as $all) { ?>
                                    <div class="col-sm-6 item">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-5">
                                                <a href="#">
                                                    <img class="img-fluid" src="../assets/img/<?php if(!empty($sary[$all->idObjet])){ echo $sary[$all->idObjet][0]; } ?>">
                                                    </a>
                                            </div>
                                            <div class="col">
                                                <h3 class="name"><?php echo $all->titre; ?></h3>
                                                <p class="description"><?php echo $all->description; ?>&nbsp;</p>
                                                <p class="prix">Prix Estimé:   <?php echo $all->prix; ?>&nbsp;</p>
                                                <p class="categorie">Categorie:   <?php echo $all->nomCategorie; ?>&nbsp;</p>
                                                <input type="checkbox" style="width:20px;height:20px" name="choix[]" value="<?php echo $all->idObjet; ?>">
                                            </div>
                                        </div>
                                    </div>
                            <?php } ?>   
                    <input type="submit" value="Choisir" class="select-modif">
                    </form>
                </div>
                                                   
            </div>
        </section>
 <script src="../assets/bootstrap/js/bootstrap.min.js">
 </script>
  <?php include('footer.php'); ?>
  </body>
     </html>