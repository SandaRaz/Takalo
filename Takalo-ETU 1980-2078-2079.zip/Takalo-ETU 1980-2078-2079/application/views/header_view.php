<?php 
    $this->load->helper('url');
?>
<nav class="navbar navbar-light navbar-expand-lg navigation-clean-search">
                    <div class="container">
                        <a class="navbar-brand" href="#">TAKALOTAKALO</a>
                        <button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1">
                            <span class="visually-hidden">Toggle navigation</span>
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navcol-1">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo base_url('../AutreUserObjet_controller'); ?>">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo base_url('../DemandeEchange_controller'); ?>">Demande</a></li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo base_url('../GestionObjet_controller'); ?>">Liste de vos objets</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo base_url('../Historique_controller'); ?>">Liste des echanges</a>
                                </li>
                            </ul>
                            <form class="me-auto search-form" target="_self">
                                <div class="d-flex align-items-center">
                                    <label class="form-label d-flex mb-0" for="search-field">
                                        <i class="fa fa-search"></i>
                                    </label>
                                    <input class="form-control search-field" type="search" id="search-field" name="search">
                                </div>
                            </form>
                        </div>
                        <a class="btn btn-light action-button" role="button" href="<?php echo base_url('../Header_controller/deco'); ?>">Deconnexion</a>
                    </div>
                </div>
</nav>