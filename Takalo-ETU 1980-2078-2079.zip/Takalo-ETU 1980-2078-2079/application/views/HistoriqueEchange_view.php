<?php 
    $this->load->model('Echange_model');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>Historiques des echanges</title>
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/styles.min.css">
    </head>
    <body>
        <section class="projects-horizontal">
            <?php include('header_view.php'); ?>
            <div class="container">
                        <div class="intro">
                            <h2 class="text-center"> Historique des echanges</h2>
                            <p class="text-center"></p>
                            </div>
                            <div class="row projects">
                            <?php foreach($historique as $all) { ?>
                                    <div class="col-sm-6 item">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-5">
                                                <a href="#">
                                                    <img class="img-fluid" src="assets/img/<?php if(!empty($sary[$all->idObjet])){ echo $sary[$all->idObjet][0]; } ?>">
                                                    </a>
                                            </div>
                                            <div class="col">
                                                <h3 class="name"><?php echo $all->titre; ?></h3>
                                                <p class="description"><?php echo $all->description; ?>&nbsp;</p>
                                                <p class="prix">Prix Estimé:   <?php echo $all->prix; ?>&nbsp;</p>
                                                <p class="daty">Date:   <?php echo $all->daty; ?>&nbsp;</p>
                                                <p class="user">Utilisateur:   <?php echo $all->nom;echo " ";echo $all->prenom; ?>&nbsp;</p>
                                            </div>
                                      </div>
                                </div>
                            <?php } ?>   

                        </div>
                    </div>
            </div>
        </section>
 <script src="assets/bootstrap/js/bootstrap.min.js">
 </script>
  <?php include('footer.php'); ?>
  </body>
     </html>