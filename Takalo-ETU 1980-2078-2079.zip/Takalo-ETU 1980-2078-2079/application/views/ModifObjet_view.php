<?php 
     $this->load->helper('url');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
    />
    <title>Modification </title>
    <link rel="stylesheet" href="../../assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="../../assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="../../assets/fonts/ionicons.min.css" />
    <link rel="stylesheet" href="../../assets/css/styles.min.css" />
  </head>
  <body>
    <section class="contact-clean">
      <div class="head">
      <nav class="navbar navbar-light navbar-expand-lg navigation-clean-search">
        <div class="container">
            <a class="navbar-brand" href="#">TAKALOTAKALO</a>
            <button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1">
                <span class="visually-hidden">Toggle navigation</span>
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Demande</a></li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Liste</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Echange</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a
                          class="dropdown-toggle nav-link"
                          aria-expanded="false"
                          data-bs-toggle="dropdown"
                          href="#"
                          >Dropdown
                        </a>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="#">First Item</a
                          ><a class="dropdown-item" href="#">Second Item</a
                          ><a class="dropdown-item" href="#">Third Item</a>
                        </div>
                      </li>
                </ul>
                <form class="me-auto search-form" target="_self">
                    <div class="d-flex align-items-center">
                        <label class="form-label d-flex mb-0" for="search-field">
                            <i class="fa fa-search"></i>
                        </label>
                        <input class="form-control search-field" type="search" id="search-field" name="search">
                    </div>

                </form>
                <a class="btn btn-light action-button" role="button" href="#">rechercher</a> 
                <a class="btn btn-light action-button" role="button" href="#">Deconnexion</a>
            </div>
            </div>
            </nav>
          </div>
    <div class="modif">

      <form method="post" action="<?php echo base_url('../ModifObjet_controller/modifier'); ?>">
        <h2 class="text-center">MODIFIER</h2>
        <input type="hidden" name="idObjet" value="<?php echo $obj->idObjet; ?>">
        <div class="mb-3">
          <input class="form-control" type="text" name="titre" placeholder="Titre" value="<?php echo $obj->titre; ?>"/>
        </div>
        <div class="mb-3">
          <input
            class="form-control "
            type="text"
            name="prix"
            placeholder="Prix"
            value="<?php echo $obj->prix; ?>"
          />
        </div>
        <div class="mb-3">
          <textarea
            class="form-control"
            name="description"
            placeholder=""
            rows="14"
          ><?php echo $obj->description; ?></textarea>
        </div>
        <select name="idCategorie" class="select-modif">
                <?php foreach($allCategorie as $all) { ?>
                    <option value="<?php echo $all->idCategorie ;?>"><?php echo $all->nomCategorie ;?></option>
                <?php } ?>
            </select>
        <div>
           
        </div>
        <div class="mb-3">
          <button class="btn btn-primary" type="submit">modifier</button>
        </div>
      </form>
    </div>
    </section>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/script.min.js"></script>
  </body>
  <?php include('footer.php'); ?>
</html>
