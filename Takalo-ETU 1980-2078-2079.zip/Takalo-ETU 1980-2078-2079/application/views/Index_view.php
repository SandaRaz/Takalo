<?php 

    $this->load->helper('url');

?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Bienvenue sur TAKALOTAKALO</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
</head>
<body>
    <section class="highlight-phone">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
    <div class="intro">
    <h2><br><strong>TAKALOTAKALO</strong><br><br></h2><p><br>Bienvenue sur notre siteweb!&nbsp; Nous sommes ravis de vous accueillir parmis nous. Notre entreprise se consacre a fournir les meilleurs services d'echange pour nos client .N'hesitez pas a parcourir le site en vous inscrivant . BON SURF<br><br></p>
    <a class="btn btn-primary" role="button" style="background-color: #055ada;"href="<?php echo base_url('../LoginFront_controller'); ?>"><br>CLIENT<br><br></a>

    <a class="btn btn-primary" role="button" href="<?php echo base_url('../LoginBack_controller'); ?>""><br><strong>ADMIN</strong><br><br></a>
</div>
</div>
<div class="col-sm-4">
    <div class="d-none d-md-block phone-mockup">
        <img class="device" src="assets/img/phone.svg">
        <div class="screen">
        </div>
</div>
</div>
</div>
</div>
</section>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body
></html>