<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
    />
    <title>Ajouter Objet</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css" />
    <link rel="stylesheet" href="assets/css/styles.min.css" />
  </head>
  <body>
    <section class="contact-clean">
    <div class="modif">

      <form method="post" action="GestionObjet_controller/inserer_new_Object" enctype="multipart/form-data">
        <h2 class="text-center">AJOUTER</h2>
        <div class="mb-3">
          <input
            class="form-control"
            type="text"
            name="titre"
            placeholder="Titre"
          />
        </div>
        <div class="mb-3">
          <input
            class="form-control "
            type="text"
            name="prix"
            placeholder="Prix"
          />
        </div>
        <div class="mb-3">
          <textarea
            class="form-control"
            name="description"
            placeholder="Description"
            rows="14"
          ></textarea>
        </div>
        <div>
           <select class="select-modif" name="idCategorie">
              <?php foreach($listeCateg as $categ) { ?>
                 <option value="<?php echo $categ->idCategorie?>"><?php echo $categ->nomCategorie; ?></option>
              <?php } ?>
          </select>
        </div>
        <div class="mb-3">
        <div>
            <input type="file" name="sary[]" id="sary" class="select-modif" multiple>
        </div>
        <div id="plus">
               
        </div>
        <p id="btn" style="font-size: 30px;">+</p>
          <button class="btn btn-primary" type="submit">AJOUTER</button>
        </div>
      </form>
    </div>
    </section>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/script.min.js"></script>
  </body>
  <script src="./addSary.js" >

</script>
</html>
