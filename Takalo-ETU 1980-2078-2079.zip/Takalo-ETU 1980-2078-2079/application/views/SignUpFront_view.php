<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>Inscription client</title>
        <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="../assets/css/styles.min.css" type="text/css">
    </head>
    <body>
        <section class="register-photo">
            <div class="form-container">
                <div class="image-holder">

                </div>
                <form method="post" action="../LoginFront_controller/inscription">
                    <h2 class="text-center">
                        <strong>Create</strong> an account.
                    </h2>
                       <div class="mb-3">
                             <input class="form-control" type="text"placeholder="Nom" name="nom">

                       </div>
                       <div class="mb-3">
                             <input class="form-control" type="text" placeholder="Prenom" name="prenom">

                        </div>
                        <div class="mb-3" >
                        <input class="form-control" type="email" name="email" placeholder="Email" name="email">

                        </div>
                        <div class="mb-3">
                            <input class="form-control" type="password" placeholder="Password" name="mdp">
                        </div>
                        <div class="mb-3">
                        <a  href="#" class="sign"> <button class="btn btn-primary d-block w-100" type="submit">Sign Up</button></a>
                            
                        </div>
                        <a href="../LoginFront_controller" class="sign">Log in</a>
                    </form>
                </div>
            </section>
            <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        </body>
        </html>