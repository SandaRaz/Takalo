<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>Gestion des objets</title>
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/styles.min.css">
    </head>
    <body>
        <section class="projects-horizontal">
        <?php include('header_view.php'); ?>
            <div class="container">
                        <div class="intro">
                            <h2 class="text-center">Mes Objets</h2>
                            <p class="text-center">Tous les objets que vous avez lancer pour un echange lucratif</p>
                            </div>
                                <div class="row projects">
                                <?php foreach($allObjet as $all) { ?>
                                    <div class="col-sm-6 item">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-5">
                                                <a href="#">
                                                        <img class="img-fluid" src="assets/img/<?php if(!empty($sary[$all->idObjet])){ echo $sary[$all->idObjet][0]; } ?>">
                                                </a>
                                            </div>
                                            <div class="col">
                                                <h3 class="name"><?php echo $all->titre; ?></h3>
                                                <p class="description"><?php echo $all->description; ?>&nbsp;</p>
                                                <p class="prix">Prix Estimé:   <?php echo $all->prix; ?>&nbsp;</p>
                                                <p class="categorie">Categorie:   <?php echo $all->nomCategorie; ?>&nbsp;</p>
                                                <a href="ModifObjet_controller/index/<?php echo $all->idObjet; ?>"><button class="btn btn-primary" type="button">Modifier</button></a>
                                                <a href="GestionObjet_controller/supprimer_Object?idObjet=<?php echo $all->idObjet; ?>"><button class="btn btn-primary" >Supprimer</button></a>
                                                <a href="GestionObjet_controller/listeEstimatif_Objet?prix=<?php echo $all->prix; ?>&marge=10"><button class="btn btn-primary" >+/-10%</button></a>
                                                <a href="GestionObjet_controller/listeEstimatif_Objet?prix=<?php echo $all->prix; ?>&marge=20"><button class="btn btn-primary" >+/-20%</button></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>                 
                            </div>  
                        </div>
            </div>
        </section>
        <?php include('AjouterObjet_view.php'); ?>
 <script src="assets/bootstrap/js/bootstrap.min.js">
 </script>
  <?php include('footer.php'); ?>
  </body>
     </html>